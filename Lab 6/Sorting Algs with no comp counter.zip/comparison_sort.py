"""
Lab6
John Wright
"""
def merge_sort(alist):
   """Takes alist and sorts it in ascending order using merge sort and returns the number of comparisons
   Author:
      John Wright
   Args:
      alist (list): list of unsorted integers
   Returns:
      (int): number of comparisons
   """
   if len(alist) <= 1:
      return alist
   midpoint = len(alist) // 2
   left = merge_sort(alist[:int(midpoint)])
   right = merge_sort(alist[int(midpoint):])
   return merge(left, right)

def merge(left, right):
   """Merges two lists together in ascending order
   Args:
      left (list): left sublist of alist from merge_sort function
      right (list): right sublist of alist from merge_sort function
   Returns:
        (int): number of comparisons
   """
   newlist = []
   left_index = 0
   right_index = 0
   comparisons = 0

   while left_index < len(left) and right_index < len(right):
      if left[left_index] <= right[right_index]:
         newlist.append(left[left_index])
         left_index += 1
      else:
         newlist.append(right[right_index])
         right_index += 1
      comparisons += 1

   while left_index < len(left):
      newlist.append(left[left_index])
      left_index += 1
   while right_index < len(right):
      newlist.append(right[right_index])
      right_index += 1
   return newlist


def insertion_sort(alist):
   """Takes alist and sorts it in ascending order using insertion sort and returns the number of comparisons
      Author:
         John Wright
      Args:
         alist (list): list of unsorted integers
      Returns:
         (int): number of comparisons
      """
   comparisons = 1
   length = len(alist)
   for i in range(1,length):
      while i > 0 and alist[i-1] > alist[i]:
         comparisons += 1
         alist[i-1], alist[i] = alist[i], alist[i-1]
         i -= 1
      comparisons += 1
   return comparisons
